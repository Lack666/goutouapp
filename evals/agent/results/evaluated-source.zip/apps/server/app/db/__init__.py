"""PostgreSQL persistence boundary."""
