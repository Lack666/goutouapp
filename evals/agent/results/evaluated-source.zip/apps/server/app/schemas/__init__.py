"""HTTP response schemas."""
