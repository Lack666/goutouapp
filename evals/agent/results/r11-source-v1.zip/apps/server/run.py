"""Run the foundation server using APP_HOST and APP_PORT settings."""

import uvicorn

from app.core.config import get_settings


def main() -> None:
    settings = get_settings()
    uvicorn.run(
        "app.main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=settings.app_debug,
        access_log=False,
    )


if __name__ == "__main__":
    main()
